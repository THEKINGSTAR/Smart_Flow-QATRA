const fs = require("fs")
const path = require("path")

console.log("🚀 Setting up SmartFlow-QATRA for local development...\n")

// Check if .env file exists
const envPath = path.join(process.cwd(), ".env")
const envExists = fs.existsSync(envPath)

if (!envExists) {
  console.log("📝 Creating .env file...")
  const envContent = `# Database Configuration
MONGODB_URI=mongodb+srv://QATRA_smart_flow-ADMIN:QATRA_smart_flow-ADMIN@cluster0.39hqks4.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0

# Session Configuration
SESSION_SECRET=4b2d19bf5112939f3c1ca2396c081de2ddf0f3327e47559352ed76ee251c7824

# Google OAuth Configuration
GOOGLE_CLIENT_ID=464571485108-1f1sg4r4m7qbm8gc923nuqdtmv1johot.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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

# Development Configuration
NODE_ENV=development
PORT=5000
`

  fs.writeFileSync(envPath, envContent)
  console.log("✅ .env file created successfully!")
} else {
  console.log("✅ .env file already exists")
}

// Check package.json
const packagePath = path.join(process.cwd(), "package.json")
if (fs.existsSync(packagePath)) {
  console.log("✅ package.json found")
} else {
  console.log("❌ package.json not found - please make sure you're in the project root")
}

console.log("\n🎯 Next steps:")
console.log("1. Run: npm install")
console.log("2. Run: npm run dev")
console.log("3. Open: http://localhost:5000")
console.log("\n🔧 Available commands:")
console.log("- npm run dev     : Start development server")
console.log("- npm run build   : Build for production")
console.log("- npm run start   : Start production server")
console.log("- npm run lint    : Run ESLint")
