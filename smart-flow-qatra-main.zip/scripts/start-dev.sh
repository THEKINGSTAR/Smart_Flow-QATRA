#!/bin/bash

echo "🚀 Starting SmartFlow-QATRA Development Server..."
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

# Check if .env file exists
if [ ! -f .env ]; then
    echo "📝 Creating .env file..."
    cat > .env << EOL
# Database Configuration
MONGODB_URI=mongodb+srv://QATRA_smart_flow-ADMIN:QATRA_smart_flow-ADMIN@cluster0.39hqks4.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0

# Session Configuration
SESSION_SECRET=4b2d19bf5112939f3c1ca2396c081de2ddf0f3327e47559352ed76ee251c7824

# Google OAuth Configuration
GOOGLE_CLIENT_ID=464571485108-1f1sg4r4m7qbm8gc923nuqdtmv1johot.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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

# Development Configuration
NODE_ENV=development
PORT=5000
EOL
    echo "✅ .env file created!"
fi

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
fi

echo ""
echo "🎯 Starting development server..."
echo "📱 Frontend: http://localhost:5173"
echo "🔧 Backend API: http://localhost:5000"
echo "📊 Admin Dashboard: http://localhost:5000/admin"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

# Start the development server
npm run dev
