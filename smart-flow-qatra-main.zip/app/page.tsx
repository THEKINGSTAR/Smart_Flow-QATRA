"use client"

import ProtectedRoute from "../admin/src/components/auth/ProtectedRoute"

export default function SyntheticV0PageForDeployment() {
  return <ProtectedRoute />
}