import type express from "express"
import session from "express-session"
import passport from "passport"
import { Strategy as LocalStrategy } from "passport-local"
import { Strategy as GoogleStrategy } from "passport-google-oauth20"
import bcrypt from "bcryptjs"
import { storage } from "./storage"
import { connectToDatabase, initializeDatabase } from "./db"

// Remove any imports from @shared/schema
// Add inline interface definitions
interface User {
  id: number
  username: string
  password: string
  email?: string
  points: number
  createdAt: Date
  oauthProvider?: string
  oauthId?: string
  displayName?: string
  firstName?: string
  lastName?: string
  profilePicture?: string
}

interface InsertOAuthUser {
  username: string
  password: string
  email?: string
  oauthProvider: string
  oauthId: string
  displayName?: string
  firstName?: string
  lastName?: string
  profilePicture?: string
}

// Initialize database connection
connectToDatabase().then(() => {
  initializeDatabase()
})

// Configure passport local strategy
passport.use(
  new LocalStrategy(async (username, password, done) => {
    try {
      const user = await storage.getUserByUsername(username)

      if (!user) {
        return done(null, false, { message: "Incorrect username." })
      }

      const isMatch = await bcrypt.compare(password, user.password)

      if (!isMatch) {
        return done(null, false, { message: "Incorrect password." })
      }

      return done(null, user)
    } catch (error) {
      return done(error)
    }
  }),
)

// Google OAuth Strategy with your credentials
passport.use(
  new GoogleStrategy(
    {
      clientID:
        process.env.GOOGLE_CLIENT_ID || "464571485108-1f1sg4r4m7qbm8gc923nuqdtmv1johot.apps.googleusercontent.com",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || "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",
      callbackURL:
        process.env.NODE_ENV === "production"
          ? "https://smartflow-qatra.vercel.app/auth/google/callback"
          : "/auth/google/callback",
    },
    async (accessToken, refreshToken, profile, done) => {
      try {
        console.log("Google OAuth callback received:", profile.id)

        // Check if user exists with this Google ID
        let user = await storage.getUserByOAuth("google", profile.id)

        if (!user) {
          // Extract user information from Google profile
          const email = profile.emails && profile.emails[0] ? profile.emails[0].value : ""
          const displayName = profile.displayName || ""
          const firstName = profile.name?.givenName || ""
          const lastName = profile.name?.familyName || ""

          // Create username from email or display name
          const username =
            email.split("@")[0] || displayName.toLowerCase().replace(/\s+/g, "") || `google_${profile.id}`

          // Generate a secure random password for OAuth users
          const password = await bcrypt.hash(Math.random().toString(36).slice(-8), 12)

          // Create new user with Google OAuth data
          user = await storage.createOAuthUser({
            username,
            password,
            email,
            displayName,
            firstName,
            lastName,
            oauthProvider: "google",
            oauthId: profile.id,
            profilePicture: profile.photos && profile.photos[0] ? profile.photos[0].value : null,
          })

          console.log("Created new Google OAuth user:", user.id)
        } else {
          console.log("Existing Google OAuth user found:", user.id)
        }

        return done(null, user)
      } catch (error) {
        console.error("Google OAuth error:", error)
        return done(error)
      }
    },
  ),
)

// Serialize and deserialize user for session management
passport.serializeUser((user: any, done) => {
  done(null, user.id)
})

passport.deserializeUser(async (id: number, done) => {
  try {
    const user = await storage.getUser(id)
    done(null, user)
  } catch (error) {
    done(error)
  }
})

// Configure session and authentication middleware
export function setupAuth(app: express.Application) {
  // Session middleware with secure configuration
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "4b2d19bf5112939f3c1ca2396c081de2ddf0f3327e47559352ed76ee251c7824",
      resave: false,
      saveUninitialized: false,
      store: storage.sessionStore,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        httpOnly: true,
        maxAge: 1000 * 60 * 60 * 24 * 7, // 1 week
        sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
      },
    }),
  )

  // Initialize passport
  app.use(passport.initialize())
  app.use(passport.session())

  // Local authentication routes
  app.post("/auth/login", passport.authenticate("local"), (req, res) => {
    res.json({
      success: true,
      user: req.user,
      message: "Login successful",
    })
  })

  app.post("/auth/register", async (req, res) => {
    try {
      const { username, password, email } = req.body

      // Validate input
      if (!username || !password || !email) {
        return res.status(400).json({ message: "Username, password, and email are required" })
      }

      // Check if username already exists
      const existingUser = await storage.getUserByUsername(username)
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" })
      }

      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(email)
      if (existingEmail) {
        return res.status(400).json({ message: "Email already registered" })
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 12)

      // Create user
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        email,
      })

      // Log in the user
      req.login(user, (err) => {
        if (err) {
          console.error("Login error after registration:", err)
          return res.status(500).json({ message: "Error logging in after registration" })
        }
        return res.json({
          success: true,
          user,
          message: "Registration successful",
        })
      })
    } catch (error) {
      console.error("Registration error:", error)
      res.status(500).json({ message: "Error registering user" })
    }
  })

  // Google OAuth routes
  app.get(
    "/auth/google",
    passport.authenticate("google", {
      scope: ["profile", "email"],
      prompt: "select_account", // Force account selection
    }),
  )

  app.get(
    "/auth/google/callback",
    passport.authenticate("google", {
      failureRedirect: "/auth?error=oauth_failed",
      successRedirect: "/",
    }),
  )

  // Logout route
  app.post("/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        console.error("Logout error:", err)
        return res.status(500).json({ message: "Error logging out" })
      }
      res.json({ success: true, message: "Logged out successfully" })
    })
  })

  // Get current user
  app.get("/auth/user", (req, res) => {
    if (req.isAuthenticated()) {
      res.json({
        success: true,
        user: req.user,
        isAuthenticated: true,
      })
    } else {
      res.json({
        success: false,
        user: null,
        isAuthenticated: false,
      })
    }
  })

  // Check admin status
  app.get("/auth/admin", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" })
    }

    try {
      const user = req.user as any
      const adminUser = await storage.getAdminUser(user.id)

      if (adminUser) {
        res.json({
          success: true,
          isAdmin: true,
          role: adminUser.role,
          permissions: adminUser.permissions || [],
        })
      } else {
        res.json({
          success: true,
          isAdmin: false,
        })
      }
    } catch (error) {
      console.error("Admin check error:", error)
      res.status(500).json({ message: "Error checking admin status" })
    }
  })
}

// Middleware to check if user is authenticated
export const isAuthenticated = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (req.isAuthenticated()) {
    return next()
  }
  res.status(401).json({ message: "Authentication required" })
}

// Middleware to check if user is admin
export const isAdmin = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Authentication required" })
  }

  try {
    const user = req.user as any
    const adminUser = await storage.getAdminUser(user.id)

    if (adminUser) {
      return next()
    } else {
      res.status(403).json({ message: "Admin access required" })
    }
  } catch (error) {
    console.error("Admin check error:", error)
    res.status(500).json({ message: "Error checking admin status" })
  }
}

export default setupAuth
